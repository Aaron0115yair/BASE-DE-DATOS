# BASE DE DATOS — proyecto Android

Aplicación Android nativa, vertical y móvil, con estética lavanda/morada.

## Funciones
- Inicio con CREAR y BUSCAR.
- Registros con nombre, descripción y desde 1 fotografía, sin límite fijo.
- Fotografías copiadas al almacenamiento privado de la app.
- Persistencia local en `files/sites.json`; no requiere internet.
- Consulta, búsqueda, edición y eliminación con confirmación.
- Exportación del sitio a PDF y hoja de compartir de Android.

## Abrir y compilar
1. Instala Android Studio en una computadora.
2. Abre la carpeta `BaseDeDatosAndroid`.
3. Deja que Gradle sincronice y descargue las dependencias.
4. Conecta un teléfono Android con depuración USB o usa un emulador.
5. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. El APK de depuración aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

## Requisitos
- Android Studio reciente.
- JDK 17.
- Android SDK Platform 35.
- Gradle se descarga automáticamente mediante Android Studio.

## Nota
Este entorno no tiene Android SDK/Gradle instalados, por lo que aquí se entrega el proyecto fuente comprimido, no un APK compilado. El proyecto no solicita permiso de internet.


## Compilar usando solo el teléfono (GitHub Actions)
1. Crea una cuenta gratuita en GitHub desde el navegador del teléfono.
2. Crea un repositorio nuevo y sube el contenido de esta carpeta (no solo el ZIP).
3. Al subirlo, conserva las carpetas y rutas, especialmente `.github/workflows/build-apk.yml`.
4. Abre la pestaña **Actions**, selecciona **Build Android APK** y pulsa **Run workflow** (o espera a que termine la ejecución iniciada por el primer push).
5. Abre la ejecución terminada, baja a **Artifacts** y descarga `BaseDeDatos-APK`.
6. Descomprime el artefacto ZIP y abre `app-debug.apk` en Android para instalarlo.

La compilación se realiza en los servidores de GitHub; no necesitas computadora ni instalar Android Studio en el teléfono.

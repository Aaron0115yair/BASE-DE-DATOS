package com.aaron.basededatos

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Purple = Color(0xFF7657A6)
private val Deep = Color(0xFF302447)
private val Lavender = Color(0xFFF4F0FB)
private val Pale = Color(0xFFECE5F7)
private val Blue = Color(0xFFE8EFFB)
private val Red = Color(0xFFF9E8E8)

data class Site(val id: String, val name: String, val description: String, val photos: List<String>)

class SiteStore(private val context: Context) {
    private val file get() = File(context.filesDir, "sites.json")
    fun load(): List<Site> = try {
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val p = o.getJSONArray("photos")
            Site(o.getString("id"), o.getString("name"), o.optString("description"), (0 until p.length()).map { p.getString(it) })
        }
    } catch (_: Exception) { emptyList() }

    fun save(sites: List<Site>) {
        val arr = JSONArray()
        sites.forEach { s ->
            val p = JSONArray(); s.photos.forEach { p.put(it) }
            arr.put(JSONObject().put("id", s.id).put("name", s.name).put("description", s.description).put("photos", p))
        }
        file.writeText(arr.toString())
    }

    fun importPhoto(uri: Uri): String? = try {
        val name = "photo_${System.currentTimeMillis()}_${(0..9999).random()}.jpg"
        val dest = File(context.filesDir, name)
        context.contentResolver.openInputStream(uri)?.use { input -> dest.outputStream().use { input.copyTo(it) } }
        dest.absolutePath
    } catch (_: Exception) { null }

    fun deleteSite(site: Site) { site.photos.forEach { runCatching { File(it).delete() } } }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(244,240,251)
        window.navigationBarColor = android.graphics.Color.rgb(244,240,251)
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContent { BaseDatosApp(this) }
    }
}

@Composable
fun BaseDatosApp(context: Context) {
    val store = remember { SiteStore(context) }
    var sites by remember { mutableStateOf(store.load()) }
    var page by remember { mutableStateOf("home") }
    var editing by remember { mutableStateOf<Site?>(null) }
    var viewing by remember { mutableStateOf<Site?>(null) }
    var query by remember { mutableStateOf("") }
    var showDelete by remember { mutableStateOf<Site?>(null) }

    fun persist(updated: List<Site>) { sites = updated; store.save(updated) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = Lavender, surface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Lavender) {
            when (page) {
                "home" -> HomeScreen(
                    onCreate = { editing = null; page = "form" },
                    onSearch = { query = ""; page = "search" }
                )
                "form" -> SiteForm(
                    initial = editing,
                    onBack = { page = if (editing == null) "home" else "detail" },
                    onSave = { name, desc, photos ->
                        val old = editing
                        val item = Site(old?.id ?: System.currentTimeMillis().toString(), name.trim(), desc.trim(), photos)
                        if (old == null) persist(sites + item) else persist(sites.map { if (it.id == old.id) item else it })
                        viewing = item; page = "detail"
                    },
                    store = store
                )
                "search" -> SearchScreen(
                    sites = sites.filter { it.name.contains(query, true) },
                    query = query,
                    onQuery = { query = it },
                    onBack = { page = "home" },
                    onOpen = { viewing = it; page = "detail" }
                )
                "detail" -> viewing?.let { site ->
                    SiteDetail(
                        site = sites.firstOrNull { it.id == site.id } ?: site,
                        onBack = { page = "search" },
                        onEdit = { editing = site; page = "form" },
                        onDelete = { showDelete = site },
                        onPdf = { exportPdf(context, site) }
                    )
                } ?: HomeScreen({ page = "form"; editing = null }, { page = "search" })
            }
            showDelete?.let { target ->
                AlertDialog(
                    onDismissRequest = { showDelete = null },
                    title = { Text("¿Eliminar este sitio?") },
                    text = { Text("Se eliminarán el registro y sus fotografías guardadas en la aplicación. Esta acción no se puede deshacer.") },
                    confirmButton = { TextButton(onClick = {
                        store.deleteSite(target); persist(sites.filterNot { it.id == target.id })
                        showDelete = null; viewing = null; page = "search"
                    }) { Text("Eliminar", color = Color(0xFFB54C4C)) } },
                    dismissButton = { TextButton(onClick = { showDelete = null }) { Text("Cancelar") } }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(onCreate: () -> Unit, onSearch: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(92.dp).clip(RoundedCornerShape(28.dp)).background(Color.White), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Storage, null, tint = Purple, modifier = Modifier.size(52.dp))
        }
        Spacer(Modifier.height(22.dp))
        Text("BASE DE DATOS", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Deep)
        Text("Tu información, organizada.", color = Color(0xFF82798E), fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp, bottom = 42.dp))
        ActionCard("CREAR", "Agregar un nuevo sitio", Icons.Default.AddCircle, true, onCreate)
        Spacer(Modifier.height(16.dp))
        ActionCard("BUSCAR", "Consultar tus sitios guardados", Icons.Default.Search, false, onSearch)
        Spacer(Modifier.height(48.dp))
        Text("♛   Todos tus registros en un solo lugar", color = Color(0xFF82798E), fontSize = 13.sp)
    }
}

@Composable
fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, filled: Boolean, onClick: () -> Unit) {
    val bg = if (filled) Purple else Color.White
    val fg = if (filled) Color.White else Deep
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(bg).clickable { onClick() }.padding(vertical = 26.dp, horizontal = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (filled) Color.White else Purple, modifier = Modifier.size(34.dp))
        Text(title, color = fg, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Text(subtitle, color = fg.copy(alpha = .82f), fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun Header(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver", tint = Purple) }
        Text(title, color = Deep, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.width(48.dp))
    }
}

@Composable
fun SiteForm(initial: Site?, onBack: () -> Unit, onSave: (String, String, List<String>) -> Unit, store: SiteStore) {
    var name by remember(initial?.id) { mutableStateOf(initial?.name ?: "") }
    var desc by remember(initial?.id) { mutableStateOf(initial?.description ?: "") }
    var photos by remember(initial?.id) { mutableStateOf(initial?.photos ?: emptyList()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val added = uris.mapNotNull { store.importPhoto(it) }
        photos = photos + added
    }
    Column(Modifier.fillMaxSize()) {
        Header(if (initial == null) "CREAR SITIO" else "EDITAR SITIO", onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Color.White).padding(18.dp)) {
                    FieldLabel("Nombre del sitio")
                    TextField(value = name, onValueChange = { name = it }, placeholder = { Text("Escribe el nombre...") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), singleLine = true, colors = fieldColors())
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PhotoCamera, null, tint = Purple)
                        Text("  Fotografías", color = Deep, fontWeight = FontWeight.SemiBold)
                    }
                    Text("Puedes agregar desde 1 fotografía y tantas como necesites.", color = Color(0xFF82798E), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                    if (photos.isNotEmpty()) {
                        photos.chunked(3).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                                row.forEach { path ->
                                    Box(Modifier.weight(1f)) {
                                        AsyncImage(model = File(path), contentDescription = null, modifier = Modifier.fillMaxWidth().height(94.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                                        IconButton(onClick = { photos = photos - path }, modifier = Modifier.align(Alignment.TopEnd).size(28.dp)) {
                                            Icon(Icons.Default.Cancel, "Quitar foto", tint = Color.White)
                                        }
                                    }
                                }
                                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                    OutlinedButton(onClick = { picker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.AddPhotoAlternate, null); Text("  AGREGAR FOTOGRAFÍAS")
                    }
                    Spacer(Modifier.height(18.dp))
                    FieldLabel("Leyenda o descripción")
                    TextField(value = desc, onValueChange = { desc = it }, placeholder = { Text("Escribe una descripción...") }, modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp), shape = RoundedCornerShape(18.dp), colors = fieldColors())
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { if (name.isNotBlank()) onSave(name, desc, photos) }, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(16.dp)) {
                        Icon(Icons.Default.Save, null); Text(if (initial == null) "  GUARDAR SITIO" else "  ACTUALIZAR SITIO", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun fieldColors() = TextFieldDefaults.colors(
    focusedBorderColor = Purple, unfocusedBorderColor = Pale,
    focusedContainerColor = Lavender, unfocusedContainerColor = Lavender,
    focusedTextColor = Deep, unfocusedTextColor = Deep
)

@Composable
fun FieldLabel(label: String) {
    Text(label, color = Deep, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
fun SearchScreen(sites: List<Site>, query: String, onQuery: (String) -> Unit, onBack: () -> Unit, onOpen: (Site) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("MIS SITIOS", onBack)
        TextField(value = query, onValueChange = onQuery, placeholder = { Text("Buscar por nombre...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(16.dp), singleLine = true, colors = fieldColors())
        if (sites.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No hay sitios guardados.", color = Color(0xFF82798E)) }
        else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(sites, key = { it.id }) { site ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color.White).clickable { onOpen(site) }.padding(14.dp)) {
                    Text(site.name, color = Deep, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("${site.photos.size} fotografías", color = Color(0xFF82798E), fontSize = 12.sp)
                    site.photos.firstOrNull()?.let { AsyncImage(File(it), null, Modifier.fillMaxWidth().height(150.dp).padding(top = 8.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop) }
                    Text(site.description, color = Deep, maxLines = 2, modifier = Modifier.padding(top = 8.dp))
                    Text("VER SITIO  →", color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.End).padding(top = 8.dp))
                }
            }
        }
    }
}

@Composable
fun SiteDetail(site: Site, onBack: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit, onPdf: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("VER SITIO", onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Color.White).padding(18.dp)) {
                    FieldLabel("Nombre del sitio")
                    ReadBox(site.name)
                    Spacer(Modifier.height(18.dp))
                    FieldLabel("Fotografías (${site.photos.size})")
                    site.photos.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                            row.forEach { path ->
                                AsyncImage(File(path), null, Modifier.weight(1f).height(145.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    FieldLabel("Leyenda o descripción")
                    ReadBox(site.description.ifBlank { "Sin descripción." })
                    Spacer(Modifier.height(18.dp))
                    HorizontalDivider(color = Pale)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallAction("DESCARGAR PDF", Icons.Default.Download, Purple, Pale, Modifier.weight(1f), onPdf)
                        SmallAction("EDITAR SITIO", Icons.Default.Edit, Color(0xFF4169A5), Blue, Modifier.weight(1f), onEdit)
                        SmallAction("ELIMINAR", Icons.Default.Delete, Color(0xFFB54C4C), Red, Modifier.weight(1f), onDelete)
                    }
                }
            }
        }
    }
}

@Composable
fun ReadBox(value: String) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Lavender).padding(15.dp)) {
        Text(value, color = Deep, fontSize = 16.sp)
    }
}

@Composable
fun SmallAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, bg: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(bg).clickable { onClick() }.padding(vertical = 12.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = color, modifier = Modifier.size(25.dp))
        Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 9.sp, lineHeight = 11.sp)
    }
}

fun exportPdf(context: Context, site: Site) {
    try {
        val pdf = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val pageWidth = 595
        val pageHeight = 842
        var pageNumber = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        var canvas = page.canvas
        var y = 55f
        paint.color = android.graphics.Color.rgb(118, 87, 166)
        paint.textSize = 24f; paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        canvas.drawText(site.name.take(38), 40f, y, paint)
        y += 32
        paint.color = android.graphics.Color.DKGRAY; paint.textSize = 12f
        canvas.drawText("BASE DE DATOS  •  ${site.photos.size} fotografías", 40f, y, paint)
        y += 28
        val descLines = site.description.chunked(78)
        descLines.forEach { line ->
            if (y > 790) {
                pdf.finishPage(page); pageNumber++
                page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()); canvas = page.canvas; y = 50f
            }
            canvas.drawText(line, 40f, y, paint); y += 17
        }
        site.photos.forEachIndexed { index, path ->
            if (y > 650) {
                pdf.finishPage(page); pageNumber++
                page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()); canvas = page.canvas; y = 50f
            }
            val bitmap = BitmapFactory.decodeFile(path)
            if (bitmap != null) {
                val scaled = android.graphics.Bitmap.createScaledBitmap(bitmap, 500, (500f * bitmap.height / bitmap.width).toInt().coerceAtMost(360), true)
                canvas.drawText("Fotografía ${index + 1}", 40f, y, paint); y += 18
                canvas.drawBitmap(scaled, 40f, y, paint); y += scaled.height + 24
                bitmap.recycle(); scaled.recycle()
            }
        }
        pdf.finishPage(page)
        val safeName = site.name.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "sitio" }
        val fileName = "${safeName}_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.pdf"
        val uri: Uri
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
            }
            val created = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("No se pudo crear el PDF en Descargas")
            context.contentResolver.openOutputStream(created)?.use { pdf.writeTo(it) }
                ?: throw IllegalStateException("No se pudo guardar el PDF")
            uri = created
        } else {
            val dir = File(context.getExternalFilesDir(null), "PDF"); dir.mkdirs()
            val out = File(dir, fileName)
            FileOutputStream(out).use { pdf.writeTo(it) }
            uri = androidx.core.content.FileProvider.getUriForFile(context, context.packageName + ".provider", out)
        }
        pdf.close()
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(share, "Compartir PDF"))
    } catch (_: Exception) {
        android.widget.Toast.makeText(context, "No se pudo crear el PDF.", android.widget.Toast.LENGTH_LONG).show()
    }
}
